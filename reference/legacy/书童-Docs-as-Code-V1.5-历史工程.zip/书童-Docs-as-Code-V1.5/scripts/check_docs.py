#!/usr/bin/env python3
"""Validate book of record: front matter, stable IDs, navigation and local Markdown links.
No third-party Python dependencies. Doesn't replace Zensical's built-in strict anchor validation.
"""
import os
import re
import sys
import tomllib
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DOCS = ROOT / 'docs'
CONFIG = ROOT / 'zensical.toml'
REQUIRED = {'doc_id', 'title', 'status', 'owner', 'source_version', 'updated'}
ALLOWED_STATUS = {'baseline', 'proposed', 'deprecated'}
errors = []

def fail(item):
    errors.append(item)

def nav_paths(node):
    if isinstance(node,str):
        yield node
    elif isinstance(node,list):
        for child in node:
            yield from nav_paths(child)
    elif isinstance(node,dict):
        for child in node.values():
            yield from nav_paths(child)

def parse_front(path,text):
    found=re.match(r'\A---\s*\n(.*?)\n---\s*\n',text,re.S)
    if not found:
        fail(f'{path}: missing YAML front matter')
        return {}
    pairs={}
    for line in found.group(1).splitlines():
        m=re.match(r'^([a-z_]+):\s*(.*?)\s*$',line)
        if m:
            pairs[m.group(1)]=m.group(2).strip('"').strip("'")
    if missing:=REQUIRED-set(pairs):fail(f'{path}: frontmatter missing {sorted(missing)}')
    if pairs.get('status') not in ALLOWED_STATUS:fail(f'{path}: invalid status {pairs.get("status")}')
    if pairs.get('updated') and not re.fullmatch(r'\d{4}-\d{2}-\d{2}',pairs['updated']):fail(f'{path}: updated must be YYYY-MM-DD')
    return pairs

config=tomllib.loads(CONFIG.read_text(encoding='utf8'))['project']
nav=set(nav_paths(config.get('nav', [])))
files={p.relative_to(DOCS).as_posix():p for p in DOCS.rglob('*.md')}
ids={}
for rel,p in files.items():
    txt=p.read_text(encoding='utf8')
    fm=parse_front(rel,txt)
    ident=fm.get('doc_id')
    if ident in ids:fail(f'doc_id reused: {ident} => {ids[ident]} and {rel}')
    if ident:ids[ident]=rel
    # YAML front matter contains values and doesn't count as a page heading.
    body=re.sub(r'\A---\s*\n.*?\n---\s*\n','',txt,count=1,flags=re.S)
    # Ignore fenced code blocks: shell '# comments' are not Markdown headings.
    body_for_headings=[]
    in_fence=False
    for line in body.splitlines():
        if line.lstrip().startswith(('```', '~~~')):
            in_fence = not in_fence
            continue
        if not in_fence: body_for_headings.append(line)
    body_for_headings=chr(10).join(body_for_headings)
    if len(re.findall(r'^# ',body_for_headings,re.M))!=1:fail(f'{rel}: must have exactly one H1')
    if rel not in nav:fail(f'{rel}: not listed in zensical navigation')
    # Markdown inline links only: path existence check; more precise anchor verification by Zensical.
    for dest in re.findall(r'(?<!!)\[[^\]]+\]\(([^\)]+)\)',body):
        if dest.startswith(('https://','http://','mailto:','#')):continue
        dest=dest.split('#',1)[0].split('?',1)[0]
        if not dest:continue
        if dest.startswith('/'):
            fail(f'{rel}: links must be relative: {dest}')
            continue
        target=(p.parent/dest).resolve()
        if not target.is_relative_to(DOCS.resolve()) or not target.exists():
            fail(f'{rel}: broken local link {dest}')
for rel in nav:
    if not rel.startswith(('http://','https://')) and rel not in files:
        fail(f'NAV references missing file: {rel}')
# Prevent accidental commitment of known sensitive binary materials in docs and raw/private directories.
for p in DOCS.rglob('*'):
    if p.is_file() and p.suffix.lower() in {'.pdf','.doc','.docx','.xlsx','.zip','.sqlite','.db','.key','.pem'}:
        fail(f'{p.relative_to(ROOT)}: potentially private or copyrighted binary inside docs tree')
print(f'Docs checked: {len(files)}; navigation entries: {len(nav)}; unique IDs: {len(ids)}')
if errors:
    print('FAILED:')
    for e in errors: print(' -',e)
    sys.exit(1)
print('PASS: document metadata, navigation, H1 and relative link targets')
