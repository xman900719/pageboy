#!/usr/bin/env python3
"""Small standard-library structural checks for versioned JSON examples.
Full JSON Schema semantic validation should be added to CI when APIs are implemented.
"""
import json, sys
from pathlib import Path
R=Path(__file__).resolve().parents[1]
schema=json.loads((R/'contracts/source-manifest.schema.json').read_text(encoding='utf8'))
example=json.loads((R/'contracts/source-manifest.example.json').read_text(encoding='utf8'))
assert schema['$schema'].endswith('2020-12/schema'), 'schema dialect mismatch'
required=set(schema['required'])
assert required<=set(example), f'missing fields: {required-set(example)}'
assert set(example)<=set(schema['properties']), 'unknown fields'
assert example['subject'] in schema['properties']['subject']['enum'], 'invalid subject'
assert example['rights_status'] in schema['properties']['rights_status']['enum'], 'invalid rights status'
assert example['rights_status']=='unknown', 'sample must not assert unverified license'
print('PASS: candidate JSON schema and synthetic example structure')
