---
doc_id: GOV-003
title: "设计—实现—测试追溯矩阵"
status: baseline
owner: maintainer
source_version: "V1.5"
updated: "2026-10-17"
---

# 设计—实现—测试追溯矩阵

## 说明

当前为**设计基线追溯表**，不是项目已经实现的证明。实现仓库路径是建议落点，未来应在代码真实建立后对齐。

| 需求领域 | 权威设计文档 | 预计代码归属 | 验收依据 |
|---|---|---|---|
| 目标与范围 | [产品定位](../01-product/positioning.md) | `apps/web` | [验收门禁](../06-quality/acceptance.md) |
| 真题解析/审核 | [真题子系统](../02-design/question-ingestion.md) | `pipelines/`, `services/api` | [验收门禁](../06-quality/acceptance.md) |
| 答题记录 | [练习闭环](../02-design/practice-loop.md) | `services/api/modules/practice` | [验收门禁](../06-quality/acceptance.md) |
| 能力画像与调度 | [GAP 引擎](../02-design/gap-engine.md) | `services/api/modules/assessment` | [验收门禁](../06-quality/acceptance.md) |
| 业务数据 | [数据模型](../03-data/data-model.md) | `services/api/migrations` | [契约目录](../04-engineering/contracts.md) |
| 运行与备份 | [部署环境](../05-operations/runtime.md) / [备份](../05-operations/backup.md) | `infra/` | [恢复手册](../05-operations/disaster-recovery.md) |

## 完成度管理

建议未来将每行增加 `issue_id / pull_request / test_case / deployed_version / last_verified_at`，并由脚本自动从代码和测试读取部分字段。初期不伪造对应工单或验收结果。
