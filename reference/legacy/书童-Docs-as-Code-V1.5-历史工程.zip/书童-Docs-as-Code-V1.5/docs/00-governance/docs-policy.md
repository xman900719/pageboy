---
doc_id: GOV-001
title: "Docs as Code 管理规范"
status: baseline
owner: maintainer
source_version: "V1.5"
updated: "2026-10-17"
---

# Docs as Code 管理规范

## 文档组织原则

1. **一处权威**：当前生效文档仅在 `docs/`；`legacy/` 仅作历史审计，不参与站点构建。
2. **小文档**：按子系统和职责拆分，不再持续扩充一份几万字的总方案。
3. **文档即变更**：改变功能、Schema、部署或风险处理时，同一 PR 更新文档与对应测试。
4. **契约优先**：稳定接口在 `contracts/`，规则计算可追溯版本与证据。
5. **证据分级**：区分已核对事实、产品假设、初版权重、尚待实现的计划。
6. **审查先于发布**：文档检查通过不代表功能已实现；设计与上线状态不可混淆。

## 状态值

| `status` | 含义 |
|---|---|
| `baseline` | 当前设计基线，不代表系统已实施 |
| `proposed` | 提议/待确认规范 |
| `deprecated` | 不再作为决策依据，保留供迁移引用 |

## 文件、命名与元数据

- 使用 `kebab-case.md` 英文路径，正文以中文书写，利于链接稳定和脚本处理。
- 每页一个一级标题；其余用二级及以下标题组织。
- 用相对路径链接文档，不直接写网页生成后的 `.html` 路径。
- 开发约束写入根目录 `AGENTS.md`，供 Codex / Agent 读取。
- 文档示例中的学校成绩、学生资料必须为合成数据且标注。
- 记录设计版本和 `updated` 日期，但**正式版本以 Git commit / tag 为准**。

## Git 审查要求

提交前执行：

```bash
python3 scripts/check_docs.py
zensical build --strict
```

变更影响到数据契约时，也要同步执行 `python3 scripts/check_contracts.py`。

## 私密性

默认私有仓库，不自动公开文档站点。不把原始试卷、学校考试照片、姓名、成绩、密钥或备份文件提交 Git。
