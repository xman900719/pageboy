---
doc_id: GOV-004
title: "V1.4 单文件文档拆分映射"
status: baseline
owner: maintainer
source_version: "V1.5"
updated: "2026-10-17"
---

# V1.4 单文件文档拆分映射

## 迁移目的

本工程不是复制四份旧文档供人分别修改，而是把**最新 V1.4 的设计内容按责任拆成唯一现行页面**，并保留原稿用于审计。

| 旧版 V1.4 内容 | 新的现行文档 |
|---|---|
| 第0–2章：定位/背景/目标 | [产品定位](../01-product/positioning.md) |
| 第3章：总体架构 | [整体架构](../02-design/system-architecture.md) |
| 第4章：真题子系统 | [真题管理](../02-design/question-ingestion.md) |
| 第5章：练习闭环 | [答题与复练](../02-design/practice-loop.md) |
| 第6章：数据模型 | [核心模型](../03-data/data-model.md) |
| 第7章：GAP Engine | [能力引擎](../02-design/gap-engine.md) |
| 第8章：技术接口 | [技术与接口](../04-engineering/tech-and-api.md) |
| 第9–11章：路线/风险/工程建议 | [路线和质量指标](../01-product/roadmap.md) |
| 第12章：运行与灾备（原文重复） | [运行环境](../05-operations/runtime.md)、[备份](../05-operations/backup.md)、[Runbook](../05-operations/disaster-recovery.md) |
| 附录：外部依据 | [来源索引](../08-references/source-links.md) |

**历史原文保存在根目录 `legacy/`。** 新需求应修改当前页面，不应继续追加到 `legacy/` 的大文件。
