---
doc_id: HOME-001
title: "书童 · 项目文档中心"
status: baseline
owner: maintainer
source_version: "V1.5"
updated: "2026-10-17"
---

# 书童 · 项目文档中心

> **文档基线 V1.5** · 本站是设计与工程规范，不代表应用已完成部署。

## 先读这里

书童是一套面向北京初三学生的个人 Web/PWA 中考真题智能练习系统，首批支持语文、数学、英语、物理。整体学习闭环为：**真题入库 → 设定目标 → 目标/现实画像 → 差距分析 → 训练 → 独立验证 → 动态修订**。

```mermaid
flowchart TD
  A[真题资源管理] --> B[审核发布题库]
  B --> C[日常练习与学校试卷]
  D[用户设定目标分数] --> E[目标能力画像]
  C --> F[现实能力画像]
  E --> G[GAP 差距引擎]
  F --> G
  G --> H[个性化练习计划]
  H --> I[独立新题评估]
  I --> F
```

## 按目的导航

| 我想了解 | 从这里开始 |
|---|---|
| 为什么做书童，首版做什么 | [产品定位与边界](01-product/positioning.md) |
| 系统有哪些模块 | [系统架构](02-design/system-architecture.md) |
| 真题如何获取、解析与审核 | [真题资源管理](02-design/question-ingestion.md) |
| 如何把目标成绩转为训练计划 | [GAP 能力引擎](02-design/gap-engine.md) |
| 数据库如何设计 | [核心数据模型](03-data/data-model.md) |
| 如何稳定运行和灾备 | [运行环境](05-operations/runtime.md) · [备份](05-operations/backup.md) · [恢复](05-operations/disaster-recovery.md) |
| 如何维护文档 | [文档管理规范](00-governance/docs-policy.md) |

## 当前实际状态

- 已完成：文档目录重构、权威内容拆分、基础校验脚本、候选数据契约、CI 工作流配置。
- 未完成：书童应用编码、真题正式入库、生产部署、灾备演练、能力模型实证校准。
- 文档构建与 GitHub CI 需在可联网并安装对应依赖的环境进一步执行验证。
