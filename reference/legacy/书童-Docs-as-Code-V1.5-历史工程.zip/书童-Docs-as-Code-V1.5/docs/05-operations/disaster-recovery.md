---
doc_id: OPS-003
title: "灾难恢复 Runbook 与演练"
status: baseline
owner: maintainer
source_version: "OPS V1.0"
updated: "2026-10-17"
---

# 灾难恢复 Runbook 与演练

## 9. 灾难恢复操作手册（DR Runbook）

### DR-01：应用容器异常，但数据库正常

1. 查看容器状态与最近日志，记录故障时刻和版本号。2. 确认磁盘空间与 DB readiness。3. 重启指定服务或回滚到上一已验证镜像。4. 用测试账号完成题目查询、提交、错题复练等冒烟测试。5. 保留故障记录。

### DR-02：误删题目、错误导入或画像被误更新

1. 封锁受影响的写入任务，记录受影响实体、版本、时间范围。2. 优先使用已有题目版本、审核记录和事件历史进行**细粒度回滚**，避免整库回退导致其他正常作答丢失。3. 如细粒度回滚不可用，从隔离恢复数据库中提取所需记录，经一致性审核后迁回。4. 验证关联原件与能力画像快照。

### DR-03：云主机磁盘损坏 / 整机不可用

1. 从独立终端确认故障，停止指向故障机的入口，记录最近成功异地快照 ID 和时间。2. 准备新 Ubuntu 主机或本地应急机，装 Docker/Compose 与私有网络客户端。3. 取回指定已验证的**数据库 dump + 对应资源快照 + 应用镜像与迁移信息 + 配置**。4. 用兼容的 PostgreSQL 版本恢复数据库；资源恢复后执行校验清单。5. 启动服务，先只读验证用户/试卷/题库/练习数据，完成端到端冒烟测试。6. 在解除维护模式后恢复写入；记录最终数据截止点、数据缺口与实际 RTO。

### DR-04：备份账号被盗或恶意删除

1. 立即禁用泄露访问密钥、撤销相关令牌、隔离运行机并保留审计日志。2. 从权限独立的不可变副本或离线副本重建**干净的新主机**；不要在未检查的旧主机上直接恢复服务。3. 验证恢复文件、镜像与依赖版本；轮换应用、数据库、对象存储及 VPN 凭据。4. 恢复后进行访问审计和数据完整性检查。

### DR-05：本地断电或网络中断

- 云端常驻模式：本地 OCR/开发任务暂停，线上已发布题库与练习应继续服务；同步恢复后采用幂等任务重试。
- 全本地部署模式：UPS 可争取有序关机时间；电力或网络恢复后容器自动启动，校验数据库与本地上传文件，确认异地备份仍有效。PWA 仅能保证事先缓存的有限阅读/草稿能力，不能假设离线全功能可用。

## 10. 最小恢复命令框架（示意，必须先在测试环境验证）

```bash
# 检查容器状态与健康
sudo docker compose ps
sudo docker compose logs --tail=200 api db

# 检查异地备份仓库与快照（需先安全提供 RESTIC_REPOSITORY 等凭据）
restic snapshots
restic check

# 将选定快照恢复到隔离目录，不直接覆盖当前服务
mkdir -p /srv/shutong-dr-test
restic restore <verified-snapshot-id> --target /srv/shutong-dr-test

# 检查从快照取回的 PostgreSQL 自定义格式备份
pg_restore --list /path/to/recovered/shutong.dump

# 示例：仅在隔离创建的空数据库中导入；版本、角色和迁移需先对齐
createdb -h <db-host> -U <restore-user> shutong_restore_test
pg_restore -h <db-host> -U <restore-user> -d shutong_restore_test   --no-owner --no-privileges /path/to/recovered/shutong.dump
```

这是恢复顺序示例，不是可直接用于生产的自动恢复脚本。`<...>` 是待填写参数。恢复实际数据库前，必须确认与原数据库主版本兼容、角色/扩展完整且使用全新或已明确清空的目标数据库；绝不能将测试还原覆盖线上库。

可选：如果以后把动态学习数据 RPO 提升到 1 小时以内，再评估 PostgreSQL **物理基础备份 + WAL 归档 + PITR**（如使用经过评估的备份管理工具）。这与上面的 `pg_dump` 逻辑备份是两种不同机制，不能混为一谈。

## 11. 故障演练与验收准则

| 演练类型 | 频率 | 合格标准 |
|---|---|---|
| 应用进程意外退出 | 每次首部署及主要版本升级 | 自动重启，提交数据不重复，关键流程正常 |
| 误删题目 / 导入错误 | 每月 | 找到版本记录、可撤销、其他作答未丢 |
| 异地完整恢复 | 每月（开始阶段至少每季度） | 从异地仓库独立恢复；引用零缺失；实际耗时记录 |
| 模拟云主机丢失 | 每季度 | 只凭备份及恢复手册，在新主机恢复核心功能 |
| 密钥/权限恢复检查 | 每季度 | 恢复人员能够取得密钥，轮换过程有记录 |
| 仓库完整性扫描 | 每周抽检、每月扩大范围 | `restic check` 无错误，读数据检查与还原测试通过 |

**验收硬门槛：** (a) S0 异地成功快照最大滞后不超过6小时（每4小时运行，预留执行缓冲；超过5小时立即告警；失败期间不得声称达标）；(b) 由备份恢复的数据库记录和附件引用完整；(c) 同一 `client_attempt_id` 重放不造成重复答题；(d) 已完成全新主机恢复演练并记录 RTO/RPO；(e) 密钥不依赖已故障的唯一电脑；(f) 上传考试卷未经授权不可由其他用户访问。

## 12. 增量实施顺序与任务验收

| 阶段 | 优先级 | 交付内容 | 验收 |
|---|---|---|---|
| OPS-0 | P0 | 分类数据资产、定义 RPO/RTO 和系统边界 | 清单完成、关键引用关系可追踪 |
| OPS-1 | P0 | Compose 部署、持久卷、健康检查、私有 HTTPS、自动重启 | 模拟掉电/重启后系统恢复，数据库未丢 |
| OPS-2 | P0 | PostgreSQL + 附件的协调备份、restic 异地加密快照、密钥留存 | 连续成功快照 + 异地实际下载恢复 |
| OPS-3 | P0 | 灾备手册与隔离恢复演练 | 从全新空机器恢复完整题库和最近练习数据 |
| OPS-4 | P1 | 外部健康监测、备份失败通知、容量告警 | 人为制造故障能在规定时间收到告警 |
| OPS-5 | P1 | 版本回滚、部署自动化、定期审计 | 故障前后可证明数据、镜像、迁移版本一致 |
| OPS-6 | P2 | WAL/PITR、温备和进一步冗余 | 仅在数据价值和故障实际要求提升后评估 |

## 13. 运行前验收测试用例（建议）

- **AC-OPS-001**：关停 `api` 进程，容器按配置重启；用户一次提交不会生成重复记录。
- **AC-OPS-002**：重启整台主机后，应用服务、数据库和私有访问自动恢复。
- **AC-OPS-003**：从独立远端仓库恢复 DB+附件，随机抽样题目/学校考试的附件哈希完全匹配。
- **AC-OPS-004**：丢失云主机本地盘后，在新主机从零部署成功，恢复过程不依赖原机器上的唯一密码。
- **AC-OPS-005**：阻断备份出站网络后，系统在目标备份延迟阈值触发告警，且不标记备份成功。
- **AC-OPS-006**：提前删除/修改已发布题库时，能够追溯原题版本，学生历史答题保持一致。
- **AC-OPS-007**：试用用户不能读取其他人的学校试卷/成绩，即使知道附件原始 ID。
- **AC-OPS-008**：PWA 发生离线重试时以幂等键去重，不能误判已同步的草稿；重新登录后识别未同步数据。

## 14. 官方依据（核查日：2026-10-17）

- PostgreSQL 备份与恢复：<https://www.postgresql.org/docs/18/backup.html>；WAL 与 PITR 区别：<https://www.postgresql.org/docs/17/continuous-archiving.html>。
- Docker Compose `depends_on: service_healthy`：<https://docs.docker.com/compose/how-tos/startup-order/>。
- restic 加密仓库及 S3：<https://restic.readthedocs.io/en/stable/030_preparing_a_new_repo.html>；完整性校验：<https://restic.readthedocs.io/en/stable/045_working_with_repos.html>；恢复：<https://restic.readthedocs.io/en/stable/050_restore.html>；保留策略：<https://restic.readthedocs.io/en/stable/060_forget.html>。
- Tailscale 私有 Serve：<https://tailscale.com/docs/features/tailscale-serve>；Caddy HTTPS（将来公开入口时）：<https://caddyserver.com/docs/automatic-https>。
- Ubuntu 自动安全更新：<https://ubuntu.com/server/docs/how-to/software/automatic-updates/>。

---

**基线结论**：书童个人版不必先买商业级高可用能力，但必须在第一位正式用户积累学习数据之前完成自动备份、独立异地副本和一次真实恢复演练。所有 RPO/RTO 属于工程目标，只有通过重复演练才可能成为可信承诺。
