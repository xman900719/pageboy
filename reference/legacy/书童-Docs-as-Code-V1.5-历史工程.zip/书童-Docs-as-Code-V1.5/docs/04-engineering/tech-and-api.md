---
doc_id: ENG-001
title: "技术选型与接口约定"
status: baseline
owner: maintainer
source_version: "V1.4"
updated: "2026-10-17"
---

# 技术选型与接口约定

## 8. 技术方案与接口约定

| 层级 | 技术建议 | 说明 |
|---|---|---|
| 前端 | React + TypeScript + Vite | 响应式手机优先，复用表单与答题组件 |
| 样式/PWA | Tailwind CSS + Manifest + Service Worker | 轻量缓存；含受限资源时避免公开离线包 |
| 服务端 | Python + FastAPI | 分模块 API；适合复用内容处理脚本 |
| 数据库 | PostgreSQL + SQLAlchemy + Alembic | 关系、题目版本、数据库迁移 |
| 原始存储 | 私有文件系统；可迁移至 S3 兼容存储 | 资源文件单独做哈希、备份 |
| 内容处理 | Python 文档解析 + 可选本地 OCR/AI | 高风险题型人工校验；模型可替换 |
| 部署 | Docker Compose / 本机私有服务器 | 单人部署，避免不必要的微服务 |
| 测试 | Pytest + Playwright | 单元、API、端到端及内容抽查 |

**接口边界示例：**

| 接口 | 行为 | 首版 |
|---|---|---|
| `POST /admin/source-files` | 导入已有文件并登记来源 | P0 |
| `POST /admin/import-jobs` | 发起解析任务 | P0 |
| `GET /admin/import-jobs/{id}` | 解析进度、错误清单 | P0 |
| `POST /admin/questions/{id}/review` | 审核及修改建议 | P0 |
| `POST /admin/questions/{id}/publish` | 规则校验后发布具体版本 | P0 |
| `GET /questions` | 仅检索已发布题目 | P0 |
| `POST /practice-sessions` | 创建练习与题目集合 | P0 |
| `POST /answer-attempts` | 保存作答事件 | P0 |
| `GET /review-tasks` | 获取到期复练题 | P0 |
| `GET /reports/knowledge` | 基于已做题生成表现报告 | P1 |
| `PUT /goals/current` | 保存分数目标与时间约束 | P0 |
| `POST /school-exams` | 学校试卷及得分录入 | P0/P1：手工录分优先，图文导入其次 |
| `GET /profiles/target`, `GET /profiles/actual` | 目标/现实能力画像 | P1 |
| `GET /gaps`, `POST /plans/generate` | 差距诊断和提升步骤 | P1 |
| `POST /effect-checks/{id}/submit` | 独立验证与计划调整 | P1 |

**安全原则：** 管理端需身份校验；原卷存储不暴露为可枚举静态目录；私人远程访问建议 HTTPS 与访问控制。PWA 缓存不应让他人在共享设备上读取原卷或个人答题数据。
