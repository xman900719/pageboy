---
doc_id: ENG-002
title: "接口与 Schema 契约目录"
status: proposed
owner: maintainer
source_version: "V1.5"
updated: "2026-10-17"
---

# 接口与 Schema 契约目录

## 约定

- 此页是**契约目录**，不是已实现接口。当前项目处于设计阶段。
- 数据契约放在仓库根目录 `contracts/`，按版本迭代；不得只把字段定义散落在聊天或 PR 描述中。
- API 的最终 OpenAPI 定义由 FastAPI 运行服务生成，审核后固定为版本化文件；当前尚无后端实现，不伪造正式接口规范。

## 现有示例

| 契约 | 路径 | 用途 | 状态 |
|---|---|---|---|
| 资源来源登记 | `contracts/source-manifest.schema.json` | 收集台账格式 | 候选示例 |
| 文档元数据 | `scripts/check_docs.py` | Front matter 字段门禁 | 已编写，需 CI 验证 |

## 交付门槛

1. 每个业务字段有类型、是否必填、含义与空值约束。
2. 不兼容变更必须发布新版本契约并增加迁移说明。
3. 学习记录、题目版本、画像证据不能丢失关联标识。
4. 契约变更对应至少一条自动化测试。

参见 [数据模型](../03-data/data-model.md) 与 [变更控制](../00-governance/change-control.md)。
