---
doc_id: DES-003
title: "答题、错题与复练闭环"
status: baseline
owner: maintainer
source_version: "V1.4"
updated: "2026-10-17"
---

# 答题、错题与复练闭环

## 5. 学习系统的核心业务闭环

```mermaid
flowchart LR
    READY[已审核题库] --> PLAN[今日训练计划]
    PLAN --> ANSWER[作答与用时记录]
    ANSWER --> CHECK[判分/采分点自评]
    CHECK --> DIAG[错因与知识点诊断]
    DIAG --> REVIEW[错题复练]
    REVIEW --> TRANSFER[未见过的同考点题验证]
    TRANSFER --> UPDATE[更新掌握状态]
    UPDATE --> PLAN
```

**五种练习模式：** 历年原卷、知识点专项、错题复练、短时综合诊断、目标差距驱动训练。差距驱动模式须在可用目标与现实证据建立后启用；若证据不足则先进行定向诊断，不假定学生不会。

**答题事件最小字段：** `learner_id`、`session_id`、`question_id`、`question_version_id`、`answer_payload`、`duration_ms`、`hint_count`、`scoring_method`（auto/self/manual）、`score_obtained`、`max_score`、`confidence_self_report`（可选）、`mistake_type`、`answered_at`。

**掌握度解释：** 正确率、独立程度、时间、复练间隔和未见题迁移表现共同构成证据。初始模型采用可解释规则与证据量，不能将内部掌握度直接映射为北京中考录取分数。
