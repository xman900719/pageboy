---
doc_id: REF-001
title: "外部依据与来源索引"
status: baseline
owner: maintainer
source_version: "V1.4"
updated: "2026-10-17"
---

# 外部依据与来源索引

## 附录 A：已经核对的外部依据与资源入口（截至 2026-10-17）

- 官方考试制度：[北京教育考试院 2026 年初中学业水平考试问题解答](https://www.bjeea.cn/html/zkzz/faq/2026/0610/88185.html)
- 官方招考政策：[北京教育考试院 2026 年中招相关通知](https://www.bjeea.cn/html/zkzz/zkzc/2026/0410/88027.html)
- 真题汇总线索：[北京高考在线 2026 年试题答案汇总](https://www.gaokzx.com/gk/zhongkao/156894.html)
- 真题汇总线索：[北京高考在线 2025 年试题答案汇总](https://www.gaokzx.com/gk/zhongkao/142623.html)
- 版权法律参考：[国家版权局《中华人民共和国著作权法》](https://www.ncac.gov.cn/xxfb/flfg/flfg_532/202103/t20210309_50530.html)

> **说明：** 汇总网页是资源发现入口，不代表其中每个真题文件已实际获取、可免费完整下载或获得再利用授权。本文所有题量、工期与质量指标均为产品规划建议，需在样本数据与真实试用中验证。



## 附录 B：能力测量与练习方法参考（截至 2026-10-17）

- [NCME：Educational Measurement（5th Edition），Scaling/Equating/Linking](https://ncme.org/wp-content/uploads/2026/01/Educational-Measurement-Fifth-Edition.pdf)：跨试卷分数等值需要满足设计与测量假设，支持“不得随意换算月考/模考/中考分”的系统门禁。
- [NCME：Multidimensional Item Response Theory Equating](https://ncme.org/resources/professional-learning/items/multidimensional-item-response-theory-equating/)：多维能力等值的测量挑战，说明真实能力画像须注意维度与条件。
- [Nature Reviews Psychology (2022)：The science of effective learning with spacing and retrieval practice](https://www.nature.com/articles/s44159-022-00089-1)：支持将分散练习、提取练习纳入候选干预策略；不为个人保证固定提分幅度。
- [Educational Psychology Review (2021)：Retrieval Practice Consistently Benefits Student Learning](https://doi.org/10.1007/s10648-021-09595-9)：为独立提取和复测的教育设计提供研究基础。

> 说明：目标能力阈值、优先级规则与周计划仅为可测试的产品设计假设。上线前应先从少量真实学校试卷与练习证据核验数据质量，再评估推荐效果。
