---
doc_id: DATA-001
title: "核心数据模型与约束"
status: baseline
owner: maintainer
source_version: "V1.4"
updated: "2026-10-17"
---

# 核心数据模型与约束

## 6. 数据库模型与约束

### 6.1 主要实体

| 数据域 | 表/实体 | 主要职责 |
|---|---|---|
| 资源 | `sources`, `source_files`, `rights_records`, `import_jobs` | 溯源、限制、文件哈希、批处理状态 |
| 试卷 | `exam_papers`, `paper_questions` | 年份、学科、原卷题号、考试制度版本 |
| 题目 | `question_groups`, `questions`, `question_parts`, `question_versions` | 题组、子题、版本、内容 |
| 内容 | `question_assets`, `answer_keys`, `rubrics` | 图文音频、正确答案、采分点 |
| 知识 | `knowledge_points`, `question_knowledge`, `knowledge_relations` | 层级、主/次考点、前置知识 |
| 审核 | `review_logs`, `publication_events` | 人工检查和题目发布追踪 |
| 学习 | `learners`, `practice_sessions`, `answer_attempts` | 本地个人档案与作答事件 |
| 目标 | `score_goals`, `goal_versions`, `exam_blueprints`, `target_abilities` | 分数目标、口径、考试蓝图和可达路径假设 |
| 校内考试 | `school_exams`, `school_exam_files`, `school_exam_items`, `school_score_records` | 批改试卷、原始成绩、题目分值与证据审核 |
| 证据画像 | `ability_evidence`, `ability_snapshots`, `gap_assessments` | 可靠性、时效、维度估计、不确定性与差距 |
| 计划 | `improvement_plans`, `plan_steps`, `assignments`, `effect_checks`, `plan_revisions` | 干预步骤、完成情况、对照测验与调度变更 |
| 推荐 | `mastery_states`, `review_tasks`, `recommendation_logs` | 可解释的学习状态和推荐依据 |

### 6.2 必须实施的约束

- `question_versions` 不可变；每次内容修订产生新版本。
- `answer_attempts` 引用具体题目版本；不得因改题而静默改历史记录。
- `exam_papers` 包含 `exam_policy_version`；`questions`/关联表包含 `current_exam_applicability`。
- 题目和原卷均有 `source_file_id` / `source_id` 可追溯关系。
- 题组与子题明确区分；作文与阅读题中的“多问”不会在统计时重复计数。
- `PUBLISHED` 的题目必须具备已审核的答案或明确的人工自评评分说明；前端只查询发布视图。
- 用户数据与内容资产物理或逻辑分离，支持导入导出、备份恢复和删除。

### 6.3 标准题目草稿示例（不是历年真实试题）

```json
{
  "id": "DEMO-MATH-001",
  "subject": "math",
  "group_id": null,
  "paper_id": null,
  "original_question_no": null,
  "type": "single_choice",
  "stem": "示例：若 x + 2 = 5，则 x = ?",
  "options": ["1", "2", "3", "4"],
  "answer": {"value": "3", "source_verified": false},
  "knowledge_points": [
    {"id": "MATH-ALG-001", "role": "primary"}
  ],
  "assets": [],
  "exam_policy_version": "2026",
  "current_exam_applicability": "unverified",
  "rights_status": "UNKNOWN",
  "status": "DRAFT",
  "version": 1
}
```
