---
doc_id: DATA-002
title: "数据来源、版权与学生隐私"
status: baseline
owner: maintainer
source_version: "V1.5"
updated: "2026-10-17"
---

# 数据来源、版权与学生隐私

## 核心原则

- **真题数据不等于自由授权内容**：原卷、答案、解析、配图分别记录来源及许可依据。
- **原卷不纳入文档 Git 仓库**：仅保存字段规范、样例结构、导入流程和来源登记模板；原卷存于私有数据仓库。
- **学校考试与未成年人资料不进入代码仓库和 CI 日志**：脱敏后方可用合成样本测试。
- **个人项目不自动公开文档网站**：本工程只做检查与本地构建，不创建 GitHub Pages 自动发布。

## 来源信息最小字段

`source_id`, `source_url`, `publisher`, `collected_at`, `rights_status`, `usage_scope`, `sha256`, `raw_asset_id`, `reviewer`, `reviewed_at`。

## 操作门禁

1. 来源不明时标记 `unknown`，不得默认为自由转载。
2. 文件导入后计算哈希，原始文件只读保留。
3. 题目结构化结果必须人工审核后才能发布。
4. 更新版权判断时，保留原判定、审核人、修订理由与时间。
5. 每次导出题库前重新检查目标使用范围。

详细处理流程见 [真题资源获取与结构化](../02-design/question-ingestion.md)，部署安全控制见 [运行与隔离](../05-operations/runtime.md)。
