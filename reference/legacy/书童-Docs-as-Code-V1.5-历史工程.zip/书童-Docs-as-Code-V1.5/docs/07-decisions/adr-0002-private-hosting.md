---
doc_id: ADR-0002
title: "ADR-0002：个人阶段采用私有单节点运行"
status: baseline
owner: maintainer
source_version: "V1.5"
updated: "2026-10-17"
---

# ADR-0002：个人阶段采用私有单节点运行

- **决策时间**：2026-10-17
- **决策状态**：已采纳（设计方向，未实施）

## 背景

个人试用阶段不需要商业级双活，但答题、学校试卷、目标/现实画像和历史证据不能随容器删除而丢失。

## 决策

采用云端轻量单节点（或家庭常驻机）+ 本地重型试卷处理 + 异地加密备份 + 定期恢复演练；与公开文档站点的自动部署分离。

## 可恢复性边界

RPO / RTO 属于**拟定目标**，只有经过真实演练才能标为 `verified`；不能将 CI 成功当作灾难恢复成功。

详见 [运行环境](../05-operations/runtime.md)、[备份](../05-operations/backup.md) 和 [恢复演练](../05-operations/disaster-recovery.md)。
