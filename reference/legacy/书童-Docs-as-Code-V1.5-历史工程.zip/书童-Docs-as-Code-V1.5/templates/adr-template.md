---
doc_id: ADR-NEXT-UNIQUE-ID
title: "ADR-XXXX：决策名称"
status: proposed
owner: maintainer
source_version: "V1.5"
updated: "2026-10-17"
---

# ADR-XXXX：决策名称

- 决策状态：待评审
- 日期：YYYY-MM-DD

## 决策背景

## 需求与约束

## 评估的候选方案

## 决策内容与原因

## 影响、迁移与回滚

## 验收与依据
