# 书童 Docs as Code 协作规范

所有变更以 Git PR（或个人分支合并）形式提交，需记录变更原因、影响文档、可能破坏的契约与验收方式。

## 提交约定

`docs: ...` 文档内容，`adr: ...` 重大决策，`contract: ...` Schema 契约，`fix(docs): ...` 文档修复。

## 操作步骤

1. 查阅 `docs/00-governance/traceability.md` 定位唯一权威页面。
2. 编辑 Markdown，更新元数据 `updated` 和相关测试要求。
3. 运行 `python3 scripts/check_docs.py && python3 scripts/check_contracts.py`。
4. 联网依赖可用时运行 `zensical build --strict`。
5. 校验通过再合并，禁止带真实学生资料测试。

跨模块设计变更应增加 ADR。详见文档规范与 PR 模板。
