# 书童 · Docs as Code V1.5

> 北京市中考真题智能练习项目的**独立文档工程骨架**，可合并到未来书童代码仓库；当前不是可运行的学生应用。

## 文档与工具

- `docs/`：当前权威设计规范，按模块独立维护。
- `legacy/`：V1.2 / V1.3 / V1.4 原始 Markdown 历史档案，不构建到站点。
- `contracts/`：候选 JSON Schema 契约和**合成**示例数据。
- `zensical.toml`：站点导航、中文界面与 Mermaid 图表配置。
- `scripts/`：无第三方依赖的元数据 / 导航 / 链接门禁和 JSON 契约检查。
- `.github/workflows/`：仅验证文档，不部署、不公开数据。
- `AGENTS.md`：AI 编码助手的文档修改约定。
- `templates/`：新设计文档和 ADR 模板（复制后须设置唯一 ID 和导航）。

## 最小运行步骤

需要 Python 3.11+，联网安装 Zensical：

```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements-docs.txt
python scripts/check_docs.py
python scripts/check_contracts.py
zensical serve
```

打开 `http://127.0.0.1:8000` 预览。提交前：

```bash
python scripts/check_docs.py
python scripts/check_contracts.py
zensical build --strict
```

> 本次生成环境无法访问 PyPI，因此仅执行了 Python 本地校验；Zensical 网站实际构建和 GitHub CI 需要在可联网的开发环境确认。

## 合并到既有代码仓库

把 `docs/`、`contracts/`、`scripts/`、`zensical.toml`、`requirements-docs.txt`、`.github/`、`AGENTS.md` 合并至书童代码仓库根目录；不要覆盖已有 `.gitignore`，需逐条合并。`legacy/` 可以作为历史设计归档带入私有仓库。

## 文档治理

修改内容请阅读 [文档管理规范](docs/00-governance/docs-policy.md) 和 [变更控制](docs/00-governance/change-control.md)。书童当前未上线，RPO/RTO 等均为设计目标而非已通过演练的 SLA。
