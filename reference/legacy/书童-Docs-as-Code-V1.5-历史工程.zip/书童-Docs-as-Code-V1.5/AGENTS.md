# 书童文档工程代理指令

本目录的当前文档权威源是 `docs/`。`legacy/` 为历史原稿，只读归档，**不得直接修改作为新需求交付**。

1. 修改任何功能时先找到 `docs/00-governance/traceability.md` 的负责页面。
2. 更新对应文档、相关 `contracts/` Schema、必要的 ADR 和验收用例；不要产生第二份互相矛盾的现行规范。
3. 设计方案状态为 `baseline` 不代表代码已实现，禁止凭空声称已部署、已验收、已取得授权。
4. 目标/现实能力画像必须保留证据与评分口径，不能将学校考试分数直接等同中考预测分数。
5. 不上传真题原卷、学生信息、学校试卷、备份文件、API Key 或其他秘密。
6. 每份文档必须保留 frontmatter 元数据，确保导航完整、链接有效。
7. 交付前执行 `python scripts/check_docs.py`、`python scripts/check_contracts.py`，有 Zensical 时执行 `zensical build --strict`。
8. 面对未确认事实须标注【待核查】；产品假设须标注【待验证】。
